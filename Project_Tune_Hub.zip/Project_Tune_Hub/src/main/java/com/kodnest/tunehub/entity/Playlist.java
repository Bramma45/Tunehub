/*
 * package com.kodnest.tunehub.entity;
 * 
 * import java.util.List;
 * 
 * import jakarta.persistence.Entity; import jakarta.persistence.GeneratedValue;
 * import jakarta.persistence.GenerationType; import jakarta.persistence.Id;
 * import jakarta.persistence.ManyToMany;
 * 
 * @Entity public class Playlist {
 * 
 * @GeneratedValue(strategy= GenerationType.AUTO)
 * 
 * @Id int id; String name;
 * 
 * @ManyToMany List<Song> song; public int getId() { return id; } public void
 * setId(int id) { this.id = id; } public String getName() { return name; }
 * public void setName(String name) { this.name = name; } public List<Song>
 * getSong() { return song; } public void setSong(List<Song> song) { this.song =
 * song; } public Playlist(int id, String name, List<Song> song) { super();
 * this.id = id; this.name = name; this.song = song; } public Playlist() {
 * super(); }
 * 
 * @Override public String toString() { return "Playlist [id=" + id + ", name="
 * + name + ", song=" + song + "]"; } }
 * 
 * package com.kodnest.tunehub.entity;
 * 
 * import java.util.List;
 * 
 * import jakarta.persistence.Entity; import jakarta.persistence.GeneratedValue;
 * import jakarta.persistence.GenerationType; import jakarta.persistence.Id;
 * import jakarta.persistence.ManyToMany;
 * 
 * @Entity public class Playlist {
 * 
 * @GeneratedValue(strategy = GenerationType.AUTO)
 * 
 * @Id int id; String name;
 * 
 * @ManyToMany List<Song> songs; public int getId() { return id; } public void
 * setId(int id) { this.id = id; } public String getName() { return name; }
 * public void setName(String name) { this.name = name; } public List<Song>
 * getSongs() { return songs; } public void setSongs(List<Song> songs) {
 * this.songs = songs; } // @Override // public String toString() { // return
 * "Playlist [id=" + id + ", name=" + name + ", songs=" + songs.size() + "]"; //
 * } public Playlist(int id, String name, List<Song> songs) { super(); this.id =
 * id; this.name = name; this.songs = songs; } public Playlist() { super(); //
 * TODO Auto-generated constructor stub }
 * 
 * @Override public String toString() { return "Playlist [id=" + id + ", name="
 * + name + "]"; }
 * 
 * 
 * }
 */
package com.kodnest.tunehub.entity;

import java.util.List;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToMany;

@Entity
public class Playlist {
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Id
	int id;
	String name;

	@ManyToMany
	List<Song> songs;

	public Playlist() {
		super();
	}

	public Playlist(int id, String name, List<Song> songs) {
		super();
		this.id = id;
		this.name = name;
		this.songs = songs;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<Song> getSongs() {
		return songs;
	}

	public void setSongs(List<Song> songs) {
		this.songs = songs;
	}

	@Override
	public String toString() {
		return "Playlist [id=" + id + ", name=" + name + ", songs=" + songs + "]";
	}
}